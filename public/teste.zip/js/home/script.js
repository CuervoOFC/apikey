// main.js

$(document).ready(function () {
  // Activate Slick Slider
  $(".testimonial-slider").slick({
    autoplay: true,
    autoplaySpeed: 5000,
    arrows: false,
    dots: true,
  });
});
